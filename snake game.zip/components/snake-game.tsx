"use client"

import { useCallback, useEffect, useRef, useState } from "react"

const CELL_SIZE = 20
const GRID_WIDTH = 20
const GRID_HEIGHT = 15
const INITIAL_SPEED = 150
const SPEED_INCREASE = 5
const MIN_SPEED = 50

type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT"
type Position = { x: number; y: number }
type GameState = "IDLE" | "PLAYING" | "GAME_OVER"
type LeaderboardEntry = { name: string; score: number; date: string }

const LOSER_MESSAGES = [
  "Oops! The snake bit the dust. Try again?",
  "That wall came out of nowhere, huh?",
  "Your snake had a bad day. Shake it off!",
  "Even the best snakes crash sometimes.",
  "The floor is lava... wait, wrong game.",
  "Snake.exe has stopped working.",
  "Task failed successfully. Ready for round 2?",
  "Plot twist: the wall won this round.",
]

const WINNER_MESSAGES = [
  "You are UNSTOPPABLE! New high score!",
  "Legend status unlocked! What a score!",
  "The snake whisperer strikes again!",
  "History has been made! You're a champion!",
  "Absolutely CRUSHING it! New record!",
  "Your dedication is paying off! Amazing!",
  "The leaderboard bows before you!",
  "That was EPIC! You're on fire!",
]

export function SnakeGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState<GameState>("IDLE")
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [previousHighScore, setPreviousHighScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [showLeaderboard, setShowLeaderboard] = useState(false)
  const [playerName, setPlayerName] = useState("")
  const [showNameInput, setShowNameInput] = useState(false)
  const [pendingScore, setPendingScore] = useState(0)
  const [gameOverMessage, setGameOverMessage] = useState("")
  const [isBeatHighScore, setIsBeatHighScore] = useState(false)

  const snakeRef = useRef<Position[]>([{ x: 10, y: 7 }])
  const directionRef = useRef<Direction>("RIGHT")
  const nextDirectionRef = useRef<Direction>("RIGHT")
  const foodRef = useRef<Position>({ x: 15, y: 7 })
  const speedRef = useRef(INITIAL_SPEED)
  const gameLoopRef = useRef<number | null>(null)
  const lastMoveTimeRef = useRef(0)

  // Load leaderboard and high score from localStorage on mount
  useEffect(() => {
    const savedLeaderboard = localStorage.getItem("snake-leaderboard")
    const savedHighScore = localStorage.getItem("snake-highscore")
    if (savedLeaderboard) {
      setLeaderboard(JSON.parse(savedLeaderboard))
    }
    if (savedHighScore) {
      const hs = parseInt(savedHighScore, 10)
      setHighScore(hs)
      setPreviousHighScore(hs)
    }
  }, [])

  // Save leaderboard to localStorage
  const saveToLeaderboard = useCallback((name: string, newScore: number) => {
    const entry: LeaderboardEntry = {
      name: name || "Anonymous",
      score: newScore,
      date: new Date().toLocaleDateString(),
    }
    setLeaderboard((prev) => {
      const updated = [...prev, entry]
        .sort((a, b) => b.score - a.score)
        .slice(0, 10)
      localStorage.setItem("snake-leaderboard", JSON.stringify(updated))
      return updated
    })
  }, [])

  const generateFood = useCallback(() => {
    let newFood: Position
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_WIDTH),
        y: Math.floor(Math.random() * GRID_HEIGHT),
      }
    } while (
      snakeRef.current.some(
        (segment) => segment.x === newFood.x && segment.y === newFood.y
      )
    )
    foodRef.current = newFood
  }, [])

  const resetGame = useCallback(() => {
    snakeRef.current = [{ x: 10, y: 7 }]
    directionRef.current = "RIGHT"
    nextDirectionRef.current = "RIGHT"
    speedRef.current = INITIAL_SPEED
    setScore(0)
    setLevel(1)
    setIsBeatHighScore(false)
    setPreviousHighScore(highScore)
    generateFood()
  }, [generateFood, highScore])

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas with cream background
    ctx.fillStyle = "#f5f5dc"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw grid dots
    ctx.fillStyle = "#e0dcc8"
    for (let x = 0; x < GRID_WIDTH; x++) {
      for (let y = 0; y < GRID_HEIGHT; y++) {
        ctx.beginPath()
        ctx.arc(
          x * CELL_SIZE + CELL_SIZE / 2,
          y * CELL_SIZE + CELL_SIZE / 2,
          1,
          0,
          Math.PI * 2
        )
        ctx.fill()
      }
    }

    // Draw snake
    snakeRef.current.forEach((segment, index) => {
      const isHead = index === 0
      ctx.fillStyle = isHead ? "#2a2a2a" : "#535353"

      // Rounded rectangle for snake segments
      const padding = 1
      const x = segment.x * CELL_SIZE + padding
      const y = segment.y * CELL_SIZE + padding
      const size = CELL_SIZE - padding * 2
      const radius = isHead ? 6 : 4

      ctx.beginPath()
      ctx.roundRect(x, y, size, size, radius)
      ctx.fill()

      // Draw eyes on head
      if (isHead) {
        ctx.fillStyle = "#f5f5dc"
        const eyeSize = 3
        const eyeOffset = 5

        if (directionRef.current === "RIGHT") {
          ctx.fillRect(x + size - eyeOffset, y + 5, eyeSize, eyeSize)
          ctx.fillRect(x + size - eyeOffset, y + size - 8, eyeSize, eyeSize)
        } else if (directionRef.current === "LEFT") {
          ctx.fillRect(x + eyeOffset - 3, y + 5, eyeSize, eyeSize)
          ctx.fillRect(x + eyeOffset - 3, y + size - 8, eyeSize, eyeSize)
        } else if (directionRef.current === "UP") {
          ctx.fillRect(x + 5, y + eyeOffset - 3, eyeSize, eyeSize)
          ctx.fillRect(x + size - 8, y + eyeOffset - 3, eyeSize, eyeSize)
        } else {
          ctx.fillRect(x + 5, y + size - eyeOffset, eyeSize, eyeSize)
          ctx.fillRect(x + size - 8, y + size - eyeOffset, eyeSize, eyeSize)
        }
      }
    })

    // Draw food with pulsing animation
    const pulseScale = 0.85 + Math.sin(Date.now() / 150) * 0.15
    const foodSize = (CELL_SIZE - 4) * pulseScale

    ctx.fillStyle = "#2a2a2a"
    ctx.beginPath()
    ctx.arc(
      foodRef.current.x * CELL_SIZE + CELL_SIZE / 2,
      foodRef.current.y * CELL_SIZE + CELL_SIZE / 2,
      foodSize / 2,
      0,
      Math.PI * 2
    )
    ctx.fill()
  }, [])

  const handleGameOver = useCallback(
    (finalScore: number) => {
      const beatHighScore = finalScore > previousHighScore && finalScore > 0
      setIsBeatHighScore(beatHighScore)

      if (beatHighScore) {
        setGameOverMessage(
          WINNER_MESSAGES[Math.floor(Math.random() * WINNER_MESSAGES.length)]
        )
        localStorage.setItem("snake-highscore", finalScore.toString())
        setHighScore(finalScore)
      } else {
        setGameOverMessage(
          LOSER_MESSAGES[Math.floor(Math.random() * LOSER_MESSAGES.length)]
        )
      }

      if (finalScore > 0) {
        setPendingScore(finalScore)
        setShowNameInput(true)
      }

      setGameState("GAME_OVER")
    },
    [previousHighScore]
  )

  const moveSnake = useCallback(() => {
    directionRef.current = nextDirectionRef.current
    const head = snakeRef.current[0]
    let newHead: Position

    switch (directionRef.current) {
      case "UP":
        newHead = { x: head.x, y: head.y - 1 }
        break
      case "DOWN":
        newHead = { x: head.x, y: head.y + 1 }
        break
      case "LEFT":
        newHead = { x: head.x - 1, y: head.y }
        break
      case "RIGHT":
        newHead = { x: head.x + 1, y: head.y }
        break
    }

    // Check wall collision
    if (
      newHead.x < 0 ||
      newHead.x >= GRID_WIDTH ||
      newHead.y < 0 ||
      newHead.y >= GRID_HEIGHT
    ) {
      handleGameOver(score)
      return
    }

    // Check self collision
    if (
      snakeRef.current.some(
        (segment) => segment.x === newHead.x && segment.y === newHead.y
      )
    ) {
      handleGameOver(score)
      return
    }

    snakeRef.current = [newHead, ...snakeRef.current]

    // Check food collision
    if (newHead.x === foodRef.current.x && newHead.y === foodRef.current.y) {
      const newScore = score + 10
      setScore(newScore)

      if (newScore > highScore) {
        setHighScore(newScore)
      }

      // Increase level every 50 points
      const newLevel = Math.floor(newScore / 50) + 1
      if (newLevel > level) {
        setLevel(newLevel)
        speedRef.current = Math.max(
          MIN_SPEED,
          INITIAL_SPEED - (newLevel - 1) * SPEED_INCREASE
        )
      }

      generateFood()
    } else {
      snakeRef.current.pop()
    }
  }, [score, level, highScore, generateFood, handleGameOver])

  const gameLoop = useCallback(
    (timestamp: number) => {
      if (gameState !== "PLAYING") return

      if (timestamp - lastMoveTimeRef.current >= speedRef.current) {
        moveSnake()
        lastMoveTimeRef.current = timestamp
      }

      draw()
      gameLoopRef.current = requestAnimationFrame(gameLoop)
    },
    [gameState, moveSnake, draw]
  )

  const startGame = useCallback(() => {
    resetGame()
    setShowNameInput(false)
    setGameState("PLAYING")
    lastMoveTimeRef.current = performance.now()
  }, [resetGame])

  const submitScore = useCallback(() => {
    if (pendingScore > 0) {
      saveToLeaderboard(playerName, pendingScore)
    }
    setShowNameInput(false)
    setPlayerName("")
    setPendingScore(0)
  }, [pendingScore, playerName, saveToLeaderboard])

  useEffect(() => {
    if (gameState === "PLAYING") {
      gameLoopRef.current = requestAnimationFrame(gameLoop)
    }

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current)
      }
    }
  }, [gameState, gameLoop])

  useEffect(() => {
    // Initial draw
    draw()
  }, [draw])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showNameInput) {
        if (e.code === "Enter") {
          e.preventDefault()
          submitScore()
        }
        return
      }

      if (gameState === "IDLE" || gameState === "GAME_OVER") {
        if (e.code === "Space" || e.code === "Enter") {
          e.preventDefault()
          startGame()
        }
        return
      }

      if (gameState !== "PLAYING") return

      switch (e.code) {
        case "ArrowUp":
        case "KeyW":
          e.preventDefault()
          if (directionRef.current !== "DOWN") {
            nextDirectionRef.current = "UP"
          }
          break
        case "ArrowDown":
        case "KeyS":
          e.preventDefault()
          if (directionRef.current !== "UP") {
            nextDirectionRef.current = "DOWN"
          }
          break
        case "ArrowLeft":
        case "KeyA":
          e.preventDefault()
          if (directionRef.current !== "RIGHT") {
            nextDirectionRef.current = "LEFT"
          }
          break
        case "ArrowRight":
        case "KeyD":
          e.preventDefault()
          if (directionRef.current !== "LEFT") {
            nextDirectionRef.current = "RIGHT"
          }
          break
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [gameState, startGame, showNameInput, submitScore])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
      {/* Header */}
      <div className="mb-4 flex w-full max-w-[400px] items-center justify-between font-mono text-sm text-foreground">
        <div className="flex items-center gap-4">
          <span className="text-muted-foreground">SCORE</span>
          <span className="text-lg font-bold tabular-nums">{score}</span>
        </div>
        <button
          onClick={() => setShowLeaderboard(!showLeaderboard)}
          className="flex items-center gap-2 rounded border border-border px-3 py-1 text-xs transition-colors hover:bg-muted"
        >
          <svg
            className="h-4 w-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
            />
          </svg>
          LEADERBOARD
        </button>
        <div className="flex items-center gap-4">
          <span className="text-muted-foreground">HI</span>
          <span className="text-lg font-bold tabular-nums">{highScore}</span>
        </div>
      </div>

      {/* Previous High Score */}
      {previousHighScore > 0 && gameState !== "IDLE" && (
        <div className="mb-2 font-mono text-xs text-muted-foreground">
          Previous Best: {previousHighScore}
        </div>
      )}

      {/* Level indicator */}
      <div className="mb-2 font-mono text-xs text-muted-foreground">
        LEVEL {level}{" "}
        {level > 1 && <span className="animate-pulse">{">"}</span>}
      </div>

      {/* Game canvas container */}
      <div className="relative overflow-hidden rounded border-2 border-foreground/20 shadow-lg">
        <canvas
          ref={canvasRef}
          width={GRID_WIDTH * CELL_SIZE}
          height={GRID_HEIGHT * CELL_SIZE}
          className="block"
        />

        {/* Leaderboard Modal */}
        {showLeaderboard && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/95 backdrop-blur-sm">
            <div className="w-full max-w-[280px] rounded border-2 border-foreground/20 bg-card p-4">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-mono text-lg font-bold">TOP SCORES</h3>
                <button
                  onClick={() => setShowLeaderboard(false)}
                  className="rounded p-1 hover:bg-muted"
                >
                  <svg
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
              {leaderboard.length === 0 ? (
                <p className="py-4 text-center font-mono text-sm text-muted-foreground">
                  No scores yet. Be the first!
                </p>
              ) : (
                <div className="space-y-2">
                  {leaderboard.map((entry, index) => (
                    <div
                      key={index}
                      className={`flex items-center justify-between rounded p-2 font-mono text-sm ${
                        index === 0
                          ? "bg-accent/20 text-accent-foreground"
                          : index < 3
                            ? "bg-muted"
                            : ""
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-6 text-center font-bold ${
                            index === 0
                              ? "text-accent"
                              : "text-muted-foreground"
                          }`}
                        >
                          {index + 1}
                        </span>
                        <span className="max-w-[100px] truncate">
                          {entry.name}
                        </span>
                      </div>
                      <span className="font-bold tabular-nums">
                        {entry.score}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Overlay screens */}
        {(gameState === "IDLE" || gameState === "GAME_OVER") &&
          !showLeaderboard && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/90 backdrop-blur-sm">
              {gameState === "GAME_OVER" && (
                <>
                  <div
                    className={`mb-2 font-mono text-3xl font-bold tracking-wider ${
                      isBeatHighScore ? "text-accent" : "text-foreground"
                    }`}
                  >
                    {isBeatHighScore ? "NEW HIGH SCORE!" : "GAME OVER"}
                  </div>

                  {/* Motivating or Loser Message */}
                  <div
                    className={`mb-3 max-w-[300px] text-center font-mono text-sm ${
                      isBeatHighScore
                        ? "text-accent"
                        : "text-muted-foreground"
                    }`}
                  >
                    {gameOverMessage}
                  </div>

                  <div className="mb-4 font-mono text-muted-foreground">
                    Score: {score}
                  </div>

                  {/* Name Input for Leaderboard */}
                  {showNameInput && (
                    <div className="mb-4 flex flex-col items-center gap-2">
                      <span className="font-mono text-xs text-muted-foreground">
                        Enter your name for the leaderboard:
                      </span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={playerName}
                          onChange={(e) =>
                            setPlayerName(e.target.value.slice(0, 12))
                          }
                          placeholder="Your name"
                          maxLength={12}
                          className="rounded border-2 border-foreground/20 bg-card px-3 py-1 font-mono text-sm focus:border-foreground focus:outline-none"
                          autoFocus
                        />
                        <button
                          onClick={submitScore}
                          className="rounded border-2 border-foreground bg-foreground px-3 py-1 font-mono text-sm text-primary-foreground transition-all hover:bg-transparent hover:text-foreground"
                        >
                          SAVE
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}

              {gameState === "IDLE" && (
                <>
                  <div className="mb-2 flex items-center gap-2">
                    <svg
                      className="h-8 w-8"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                    >
                      <rect x="2" y="8" width="4" height="4" rx="1" />
                      <rect x="6" y="8" width="4" height="4" rx="1" />
                      <rect x="10" y="8" width="4" height="4" rx="1" />
                      <rect x="14" y="8" width="4" height="4" rx="1" />
                      <rect x="18" y="8" width="4" height="4" rx="1" />
                      <rect x="14" y="12" width="4" height="4" rx="1" />
                    </svg>
                  </div>
                  <div className="mb-1 font-mono text-2xl font-bold tracking-wider text-foreground">
                    SNAKE
                  </div>
                  <div className="mb-4 font-mono text-xs text-muted-foreground">
                    No internet? No problem.
                  </div>
                  {highScore > 0 && (
                    <div className="mb-4 font-mono text-sm text-muted-foreground">
                      High Score to Beat: {highScore}
                    </div>
                  )}
                </>
              )}

              {!showNameInput && (
                <button
                  onClick={startGame}
                  className="group flex items-center gap-2 rounded border-2 border-foreground bg-foreground px-6 py-2 font-mono text-sm font-medium text-primary-foreground transition-all hover:bg-transparent hover:text-foreground"
                >
                  {gameState === "GAME_OVER" ? "PLAY AGAIN" : "START GAME"}
                  <span className="text-xs opacity-60">[SPACE]</span>
                </button>
              )}

              {gameState === "IDLE" && (
                <div className="mt-6 flex flex-col items-center gap-2 font-mono text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <kbd className="rounded border border-border bg-muted px-2 py-1">
                        {"^"}
                      </kbd>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <kbd className="rounded border border-border bg-muted px-2 py-1">
                      {"<"}
                    </kbd>
                    <kbd className="rounded border border-border bg-muted px-2 py-1">
                      {"v"}
                    </kbd>
                    <kbd className="rounded border border-border bg-muted px-2 py-1">
                      {">"}
                    </kbd>
                  </div>
                  <span className="mt-1">Arrow keys to move</span>
                </div>
              )}
            </div>
          )}
      </div>

      {/* Footer */}
      <div className="mt-4 font-mono text-xs text-muted-foreground">
        {gameState === "PLAYING" ? (
          <span className="animate-pulse">Eat food to grow longer...</span>
        ) : (
          <span>Press SPACE or click to start</span>
        )}
      </div>

      {/* Speed indicator */}
      {gameState === "PLAYING" && (
        <div className="mt-2 flex items-center gap-2 font-mono text-xs text-muted-foreground">
          <span>SPEED</span>
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className={`h-2 w-1 rounded-sm ${
                  i < level ? "bg-foreground" : "bg-border"
                }`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
